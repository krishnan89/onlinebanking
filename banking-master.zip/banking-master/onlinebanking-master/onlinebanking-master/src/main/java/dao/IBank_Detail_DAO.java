package dao;

import java.util.List;
import actionForm.Bank_Detail;

public interface IBank_Detail_DAO {
	public List<Bank_Detail> list();
}
